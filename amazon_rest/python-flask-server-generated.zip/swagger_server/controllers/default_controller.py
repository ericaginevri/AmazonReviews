import connexion
import six

from swagger_server.models.hadoop_request import HadoopRequest  # noqa: E501
from swagger_server.models.spark_request import SparkRequest  # noqa: E501
from swagger_server import util


def get_hadoop_results():  # noqa: E501
    """Get Hadoop results

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def get_spark_results():  # noqa: E501
    """Get Spark results

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def run_hadoop(body):  # noqa: E501
    """Run Hadoop job

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = HadoopRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def run_spark(body):  # noqa: E501
    """Run Spark job

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = SparkRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
